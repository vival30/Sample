/*
 * CollectionController.java 7:44:54 PM Apr 30, 2010 version 1.0
 * 
 * Copyright (c) 1998-2010 Cognizant Technology Solutions, Inc. All Rights
 * Reserved.
 * 
 * This software is the confidential and proprietary information of Cognizant
 * Technology Solutions. ("Confidential Information"). You shall not disclose
 * such Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Cognizant.
 */

package com.omega.controller;

import com.omega.dtd.Vehicle;
import com.omega.exception.InValidVehicleException;
import com.omega.exception.ServiceException;

import com.omega.service.IPremiumCalculation;
import com.omega.service.PremiumCalculation;

import com.omega.utility.Validation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author Java CoE
 * 
 *         Servlet Controller. Receives vehicle form data Validates for Business
 *         and data correctness and calculates the premium
 * @version 1.0
 */
public class CollectionController extends javax.servlet.http.HttpServlet
{
    

    /** Serial Version for the class */
    static final long serialVersionUID = 1L;
    
    /** Logger */
    private static final Logger LOGGER = LoggerFactory
            .getLogger(CollectionController.class.getName());
    
    /**
     * {@inheritDoc}
     */
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException
    {
            if (LOGGER.isDebugEnabled())
        {
            LOGGER
                    .debug("[CollectionController].df gd[doGet] Receiving Vechile form data");
        }
            
           /*try {
            	 
        		DefaultHttpClient httpClient = new DefaultHttpClient();
        		//HttpGet getRequest = new HttpGet("http://localhost:8080/asset-repository-webapp-1.0/AssetRepositoryService/getUsecases?applicationId=1");
        		
        		HttpGet getRequest = new HttpGet("http://localhost:8080/CallTracerWeb/startstopserver.do?action=stop");

        		getRequest.addHeader("accept", "application/xml");
        		
         
        		HttpResponse response1 = httpClient.execute(getRequest);
        		System.out.println("STATUS: " + response1.getStatusLine().getStatusCode() );
        		System.out.println("STATUS: " + response1.getStatusLine().getReasonPhrase() );

        		if (response1.getStatusLine().getStatusCode() != 200) {
        			throw new RuntimeException("Failed : HTTP error code : "
        			   + response1.getStatusLine().getStatusCode());
        		}
         
        		BufferedReader br = new BufferedReader(
                                 new InputStreamReader((response1.getEntity().getContent())));
         
        		String output;
        		System.out.println("Output from Server .... \n");
        		while ((output = br.readLine()) != null) {
        			System.out.println(output);
        		}
         
        		httpClient.getConnectionManager().shutdown();
         
        	  } catch (ClientProtocolException e) {
         
        		e.printStackTrace();
         
        	  } catch (IOException e) {
         
        		e.printStackTrace();
        	  }*/

        Validation validation = new Validation();
        IPremiumCalculation premium = new PremiumCalculation();
        Vehicle vehicleDetails;
        
        try
        {
            // validate data for correctness and business conditions
            vehicleDetails = validation.constructValidVehicle(request);
            // calculate premium.
            vehicleDetails.setPremium(premium.calculatePremium(vehicleDetails));
            System.out.println("PREMIUM: " +premium.calculatePremium(vehicleDetails));
            
        } catch (InValidVehicleException excep)
        {
            request.setAttribute("error", excep.getLocalizedMessage());
            throw new ServletException(excep);
            
        } catch (ServiceException exce)
        {
            request.setAttribute("error", exce.getLocalizedMessage());
            throw new ServletException(exce);
        }
        // once premium is calculated forward the request.
        request.setAttribute("insureVehicle", vehicleDetails);
        RequestDispatcher view = request
                .getRequestDispatcher("displayQuatation.jsp");
        view.forward(request, response);
        
    }
    /*
     * This line is added for Hudson Demo
     */
}
