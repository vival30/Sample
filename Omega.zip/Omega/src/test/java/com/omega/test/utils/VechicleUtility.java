
package com.omega.test.utils;

import org.junit.Before;

import com.omega.dtd.Vehicle;

/**
 * @author 167522
 * 
 */
public class VechicleUtility
{
    

    /**
     * 
     */
    public Vehicle testVechile = null;
    
    /**
     * 
     */
    @Before
    public void createTestVechicle()
    {

        testVechile = new Vehicle();
        testVechile.setAge(12);
        testVechile.setCoverageAmount(5000);
        testVechile.setCoverageType("BI");
        testVechile.setGender("Male");
        testVechile.setLicenseNumber("120tn38");
        testVechile.setLstYearAccidents(2);
        testVechile.setMake("Ford");
        testVechile.setName("Fiesta");
        testVechile.setSsn(1234567890);
        testVechile.setVehicleModel("TDCI");
        testVechile.setYear(1998);
    }
}
