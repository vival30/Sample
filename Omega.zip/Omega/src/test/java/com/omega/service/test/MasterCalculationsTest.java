
package com.omega.service.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.omega.service.MasterCalculations;

/**
 * This class contains one testXXXX method per XXXXX method in source class
 * @author
 **/
// TODO Add Junit jar in build path.
// TODO Modify input and output data if needed.

public class MasterCalculationsTest
{
    

    // TODO add assert() method
    /**
     * 
     */
    @Test
    public void testSequence()
    {

        MasterCalculations aa = new MasterCalculations();
        // assertEquals("b zero", MasterCalculations.getBigger(-22,0));
        assertEquals("greater than", MasterCalculations.getBigger(-21, -43));
        assertEquals("less than", MasterCalculations.getBigger(34, 75));
        assertEquals("less than", MasterCalculations.getBigger(-84, -37));
        assertEquals("less than", MasterCalculations.getBigger(13, 57));
        assertEquals("less than", MasterCalculations.getBigger(-8, 9));
        assertEquals("greater than", MasterCalculations.getBigger(45, -90));
        assertEquals("greater than", MasterCalculations.getBigger(75, -51));
        assertEquals("less than", MasterCalculations.getBigger(-29, 51));
        assertEquals("greater than", MasterCalculations.getBigger(61, -23));
    }
    
}
