﻿using System;

namespace ConsoleCoreapp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            int a = 5, b = 6;
            Console.WriteLine(a + b);
            Console.ReadKey();
        }
    }
}